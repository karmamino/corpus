# -*- coding: utf-8 -*-

import os

def get_input_file():
    print('\n입력파일의 이름이나 전체 경로를 입력하세요')
    print('현재 경로:', os.getcwd())
    in_fname = input('>> ' )
    if os.path.isfile(in_fname):
        pass
    else:
        while os.path.isfile(in_fname) == False:
            print('없는 파일입니다. 다시 입력하세요.')
            in_fname = input('>> ' )
    return in_fname

def get_output_file():
    print('\n출력파일의 이름이나 전체 경로를 입력하세요')
    print('현재 경로:', os.getcwd())    
    out_fname = input('>> ' ) 
    return out_fname
    
def clear_para(para):
    para = para.replace('<p>', '')
    para = para.replace('</p>', '')
    para = para.replace('<head>', '')
    para = para.replace('</head>', '')
    return para.strip()

print('=' * 50)
print('21세기 세종계획 원시말뭉치 내용 추출')
print('=' * 50)

try:
    in_fname = get_input_file()   
    out_fname = get_output_file()
    
    with open(in_fname, encoding='utf-16le') as f:
        paras = [clear_para(para) for para in f if '<p>' in para or '<head>' in para]        
    with open(out_fname, 'w', encoding='utf-8') as f:
        f.write('\n'.join(paras))
        
    word_cnt = 0
    for para in paras:
        word_cnt += para.count(' ')
        word_cnt += 1
            
    print('=' * 50)
    print('%d 문단, %d 어절 추출 완료' % (len(paras), word_cnt))
    print('=' * 50)    

except FileNotFoundError as e:
    print(e)
        