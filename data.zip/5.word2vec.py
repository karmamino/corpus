import os
import logging
from pprint import *
from gensim.models import word2vec
from gensim.models import FastText

from sklearn.manifold import TSNE
import matplotlib as mpl
import matplotlib.pyplot as plt

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)


# =============================================================================
#    함수 정의
# =============================================================================
def get_input_file():
    print('\n입력파일의 이름이나 전체 경로를 입력하세요')
    print('현재 경로:', os.getcwd())
    in_fname = input('>> ' )
    if os.path.isfile(in_fname):
        pass
    else:
        while os.path.isfile(in_fname) == False:
            print('없는 파일입니다. 다시 입력하세요.')
            in_fname = input('>> ' )
    return in_fname

# "x1" is to "x2" as "y1" is to ?
def analogy(x1, x2, y1):
    result = model.most_similar(positive=[y1, x2], negative=[x1])
    return result[0][0]
# =============================================================================
#    파일 입력
# =============================================================================
print('=' * 50)
print('워드임베딩')
print('=' * 50)


in_fname = get_input_file()      
    
# =============================================================================
#    워드임베딩 시작
# =============================================================================
data = word2vec.LineSentence(in_fname)
model = word2vec.Word2Vec(data,
                          size=200,         # Dimensionality of the word vectors
                          window=10,        # Maximum distance between the current and predicted word within a sentence
                          hs=0,             # If 1, hierarchical softmax will be used for model training. If 0, and negative is non-zero, negative sampling will be used.                          
                          sg=1,             # Training algorithm: 1 for skip-gram; otherwise CBOW.
                          min_count=2,
                          workers=6         # Number of the threads   
                          )
model.save('skipgram_lemma.model')

"""
model = word2vec.Word2Vec(data,
                          size=200,         # Dimensionality of the word vectors
                          window=10,        # Maximum distance between the current and predicted word within a sentence
                          hs=0,             # If 1, hierarchical softmax will be used for model training. If 0, and negative is non-zero, negative sampling will be used.                          
                          sg=0,             # Training algorithm: 1 for skip-gram; otherwise CBOW.
                          min_count=2,
                          workers=6         # Number of the threads   
                          )
model.save('cbow_lemma.model')

model = FastText(data, 
                 size=200, 
                 window=10, 
                 hs=0, 
                 sg=1, 
                 min_count=2, 
                 workers=6)
model.save('fasttext_lemma.model')
"""
# =============================================================================
#    워드임베딩 결과 시각화
# =============================================================================
mpl.rcParams['axes.unicode_minus'] = False
vocab = list(model.wv.vocab)
X = model[vocab]
tsne = TSNE(n_components=2)
X_tsne = tsne.fit_transform(X[:100,:])

df = pd.DataFrame(X_tsne, index=vocab[:100], columns=['x', 'y'])
df.shape

fig = plt.figure()
fig.set_size_inches(40, 20)
ax = fig.add_subplot(1, 1, 1)

ax.scatter(df['x'], df['y'])

for word, pos in df.iterrows():
    ax.annotate(word, pos, fontsize=30)

fig = plt.gcf()
plt.show()
fig.savefig('word2vec.pdf')

# =============================================================================
#    워드임베딩 결과 평가
# =============================================================================
sg_model = word2vec.Word2Vec.load('skipgram_lemma.model')
pprint(sg_model.wv.most_similar('어둠'))
print(sg_model.wv.similarity('어둠', '발소리'))

#analogy('Berlin', 'Germany', 'Cairo')

"""
cb_model = word2vec.Word2Vec.load('cbow_lemma.model')
ft_model = word2vec.Word2Vec.load('fasttext_lemma.model')

sg_score, sg_section  = sg_model.wv.evaluate_word_analogies(analogies='kor_analogy.txt', dummy4unknown=True)
cb_score, cb_section  = cb_model.wv.evaluate_word_analogies(analogies='kor_analogy.txt', dummy4unknown=True)
ft_socre, ft_section = ft_model.wv.evaluate_word_analogies(analogies='kor_analogy.txt', dummy4unknown=True)
"""



