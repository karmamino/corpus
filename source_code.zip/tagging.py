# -*- coding: utf-8 -*-
import os
from konlpy.tag import Kkma

def get_input_file():
    print('\n입력파일의 이름이나 전체 경로를 입력하세요')
    print('현재 경로:', os.getcwd())
    in_fname = input('>> ' )
    if os.path.isfile(in_fname):
        pass
    else:
        while os.path.isfile(in_fname) == False:
            print('없는 파일입니다. 다시 입력하세요.')
            in_fname = input('>> ' )
    return in_fname

try:
    print('=' * 50)
    print('형태소 분석 프로그램')
    print('=' * 50)

    in_fname = get_input_file()      
    with open(in_fname, encoding='utf-8') as f:
        lines = [line.strip() for line in f]
        
    kkma = Kkma()
    
    print('=' * 50)
    print('분석 파일 생성 방법')
    print('=' * 50)    
    print('1. 모든 형태소 출력 - 품사 정보 미포함')
    print('2. 모든 형태소 출력 - 품사 정보 포함')
    print('3. 명사만 출력')
    print('=' * 50)    
    menu = int(input('>> '))
    
    while True:
        if menu == 1:
            with open('tagging.all.txt', 'w', encoding='utf-8') as f:        
                for line in lines:
                    f.write('%s\n' % ' '.join(kkma.morphs(line)))                
        elif menu == 2:
            with open('tagging.all.pos.txt', 'w', encoding='utf-8') as f:        
                for line in lines:
                    morp_list = kkma.pos(line)
                    temp = ['/'.join(morp) for morp in morp_list]                    
                    f.write('%s\n' % ' '.join(temp))                            
        elif menu == 3:
            with open('tagging.noun.txt', 'w', encoding='utf-8') as f:        
                for line in lines:
                    f.write('%s\n' % ' '.join(kkma.nouns(line)))                            
        else:
            print('메뉴 선택은 숫자만 입력하셔야 합니다.')                            
            menu = int(input('>> '))        
            continue
        break
        
except FileNotFoundError:
    print('해당 파일을 찾을 수 없습니다.')
except UnicodeDecodeError:
    print('문서 인코딩을 확인하세요. utf-8 문서만 처리 가능합니다.')