# -*- coding: utf-8 -*-
import os
import sys
import pandas as pd
from collections import Counter
from pprint import pprint

def get_input_file():
    print('\n입력파일의 이름이나 전체 경로를 입력하세요')
    print('현재 경로:', os.getcwd())
    in_fname = input('>> ' )
    if os.path.isfile(in_fname):
        pass
    else:
        while os.path.isfile(in_fname) == False:
            print('없는 파일입니다. 다시 입력하세요.')
            in_fname = input('>> ' )
    return in_fname

print('=' * 50)
print('빈도 추출 프로그램')
print('=' * 50)

try:
    in_fname = get_input_file()      
    with open(in_fname, encoding='utf-8') as f:
        lines = [line.strip() for line in f]
    
    token_cnt = Counter(eojeol for line in lines for eojeol in line.split(' '))
    types = len(token_cnt)
    tokens = sum(token_cnt.values())
    
    print('=' * 50)
    print('token:', tokens)
    print('type:', types)
    print('token/type = %.2f' % (tokens/types))
    print('type/token = %.2f' % (types/tokens))
    
    print('=' * 50)  
    
    sorted_token_cnt = sorted(token_cnt.items(), key=lambda x:x[1], reverse=True)        

    pd.options.display.float_format = '{:.3f}'.format    
    token_pd = pd.DataFrame.from_dict(sorted_token_cnt)    
    token_pd.rename(columns={token_pd.columns[0]:'토큰', token_pd.columns[1]:'빈도' }, inplace=True)
    token_pd['백분율'] = token_pd['빈도'] / tokens * 100 
    token_pd['누적백분율'] = token_pd['빈도'].cumsum() / tokens * 100
    
    print(token_pd)    
    
    if len(sys.argv) == 2 and sys.argv[1][-3:] == 'csv':        
        token_pd.to_csv(sys.argv[1], index = None, header = True)             
    else:
        token_pd.to_csv('freq.csv', index = None, header = True)         
        
        
    import matplotlib.font_manager as fm
    import matplotlib.pyplot as plt
    import matplotlib
    font_location = 'C:/Windows/Fonts/malgun.ttf'  
    font_name = fm.FontProperties(fname = font_location).get_name()
    matplotlib.rc('font', family = font_name)
    
    token_pd.plot(y='누적백분율')
    plt.axhline(y=90, color='r', linewidth=2)
    plt.xlabel('토큰 번호')    
    fic = plt.gcf()
    plt.show()
    fic.savefig('freq.pdf')
    
    
    ranks = []
    freqs = []    
    freqs2 = []
    rank = 1
    for freq in token_pd['빈도'][:1000]:
        ranks.append(rank)
        rank += 1
        freqs.append(freq)
        
    for i in range(1000):
        freqs2.append(token_pd['빈도'][0] / (i + 1))
        
    plt.plot(ranks, freqs, label='실제값')
    plt.plot(ranks, freqs2, label="Zipf's law")
    plt.xlabel('순위')    
    plt.ylabel('빈도')    
    plt.legend()
    fic = plt.gcf()
    plt.grid(True)
    plt.show()
    fic.savefig('zipf.pdf')
    
    
    
                          
except FileNotFoundError:
    print('해당 파일을 찾을 수 없습니다.')
except UnicodeDecodeError:
    print('문서 인코딩을 확인하세요. utf-8 문서만 처리 가능합니다.')
        