# -*- coding: utf-8 -*-
import os
import tqdm
from konlpy.tag import Kkma

# =============================================================================
# 함수 정의
# =============================================================================
def get_input_file():
    print('\n입력파일의 이름이나 전체 경로를 입력하세요')
    print('현재 경로:', os.getcwd())
    in_fname = input('>> ' )
    if os.path.isfile(in_fname):
        pass
    else:
        while os.path.isfile(in_fname) == False:
            print('없는 파일입니다. 다시 입력하세요.')
            in_fname = input('>> ' )
    return in_fname
    
# =============================================================================
# 문장 분리
# =============================================================================
    print('=' * 50)
    print('문장 분리 프로그램')
    print('=' * 50)

try:
    
    in_fname = get_input_file()      
    with open(in_fname, encoding='utf-8') as f:
        lines = [line.strip() for line in f]
        
    kkma = Kkma()
    with open('sentence.txt', 'w', encoding='utf-8') as f:        
        for i in tqdm.trange(len(lines)):
            f.write('%s\n' % '\n'.join(kkma.sentences(lines[i])))        
        
except FileNotFoundError:
    print('해당 파일을 찾을 수 없습니다.')
except UnicodeDecodeError:
    print('문서 인코딩을 확인하세요. utf-8 문서만 처리 가능합니다.')