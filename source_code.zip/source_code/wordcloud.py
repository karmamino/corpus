import glob
from collections import Counter
from pprint import pprint

#%%
class Documents:
    def __init__(self, fnames, yield_text=True, yield_tag=True):
        self.fnames = fnames
        self.yield_text = yield_text
        self.yield_tag = yield_tag
    def __iter__(self):
        if self.yield_text or self.yield_tag:
            for fname in self.fnames:
                with open(fname, encoding='utf-8') as f:
                    for row in f:
                        sent, tag = row.strip().split('\t')
                        if self.yield_text and self.yield_tag:
                            yield (sent.split(), tag.split())
                        elif self.yield_text:
                            yield sent.split()
                        elif self.yield_tag:
                            yield tag.split()
                            
#%%
fnames = glob.glob('./refinement/*.txt')
print('num files = %d' % len(fnames))

#%% 문장의 수
docs = Documents(fnames, yield_text=True, yield_tag=False)
for n_sent, _ in enumerate(docs):
    continue
print('num sents = %d' % (n_sent+1))                           

#%% 어절의 수
docs = Documents(fnames, yield_text=True, yield_tag=False)
counter = Counter((eojeol for sent in docs for eojeol in sent))

print('num eojeols = %d' % (sum(counter.values())))
print('unique num eojeols = %d' % (len(counter)))

#%%
print('Top 50 eojeols')
with open('temp.txt', 'w', encoding='utf-8') as f:
    pprint(sorted(counter.items(), key=lambda x:x[1], reverse=True)[:50], f)
#%% 형태소의 수
docs = Documents(fnames, yield_text=False, yield_tag=True)
counter_wordtag = Counter((w for sent in docs for eojeol in sent for w in eojeol.split('+')))
        
print('num (word,tag) = %d' % (sum(counter_wordtag.values())))
print('unique (word,tag) = %d' % (len(counter_wordtag)))

#print('Top 50 (word,tag)')
#pprint(sorted(counter_wordtag.items(), key=lambda x:x[1], reverse=True)[:50])

#%% 태그열 출력
#for tag_seq in docs:
#    print(tag_seq)

#%%
from wordcloud import WordCloud
import matplotlib.pyplot as plt
#from matplotlib import font_manager, rc
#font_name = font_manager.FontProperties(fname="C:/Windows/Fonts/malgun.ttf").get_name()
#rc('font', family=font_name)
wc = WordCloud(
        font_path="C:/Windows/Fonts/malgun.ttf",
        relative_scaling = 0.2,
        background_color = "white")    
plt.figure(figsize=(16,8))
plt.imshow(wc.generate_from_frequencies(counter))
plt.axis("off")
plt.show()